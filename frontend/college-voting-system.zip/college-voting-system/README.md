# 🗳️ College Voting System — VoteSecure

A full-stack, OTP-authenticated college election platform with live results, admin dashboard, and CSV bulk import.

---

## 📁 Project Structure

```
college-voting-system/
├── backend/
│   ├── models/
│   │   ├── Student.js        # Student schema (OTP, hasVoted, etc.)
│   │   ├── Vote.js           # Vote schema (studentId + candidateId)
│   │   ├── Admin.js          # Admin schema (bcrypt password)
│   │   ├── Candidate.js      # Candidate schema (votes count)
│   │   └── Election.js       # Election state (active/inactive/closed)
│   ├── routes/
│   │   ├── auth.js           # POST /send-otp, POST /verify-otp
│   │   ├── vote.js           # POST /cast, GET /candidates
│   │   ├── admin.js          # POST /login, GET /dashboard, election control
│   │   ├── students.js       # CRUD + CSV upload + export
│   │   ├── candidates.js     # CRUD candidates
│   │   └── results.js        # GET live results + CSV export
│   ├── middleware/
│   │   ├── auth.js           # JWT protect middleware
│   │   └── email.js          # Nodemailer OTP sender
│   ├── uploads/              # Temp CSV upload directory
│   ├── server.js             # Express app entry point
│   ├── seed.js               # Database seeder
│   ├── package.json
│   └── .env.example          # Environment variables template
│
├── frontend/
│   ├── assets/
│   │   ├── css/style.css     # Global dark theme styles
│   │   └── js/utils.js       # Shared API, Toast, Auth utilities
│   ├── pages/
│   │   ├── login.html        # Roll number entry
│   │   ├── otp.html          # OTP verification (digit boxes)
│   │   ├── vote.html         # Candidate selection + voting
│   │   ├── results.html      # Live results (Bar + Pie charts)
│   │   ├── admin-login.html  # Admin secure login
│   │   └── dashboard.html    # Full admin dashboard
│   └── index.html            # Home / landing page
│
└── sample_students.csv        # Sample CSV for testing bulk import
```

---

## ⚡ Quick Setup

### Prerequisites
- Node.js v18+
- MongoDB (local or Atlas)
- Gmail account (for OTP emails)

---

### 1. Backend Setup

```bash
cd backend
npm install
cp .env.example .env
```

Edit `.env` with your values:
```env
MONGODB_URI=mongodb://localhost:27017/college_voting
JWT_SECRET=your_very_secret_key_here
EMAIL_USER=your_gmail@gmail.com
EMAIL_PASS=your_gmail_app_password   # Use Gmail App Password, not regular password
```

> **Gmail App Password**: Go to Google Account → Security → 2-Step Verification → App Passwords

### 2. Seed the Database

```bash
npm run seed
```

This creates:
- ✅ Admin: `admin@college.edu` / `Admin@123`
- ✅ 10 sample students
- ✅ 4 sample candidates
- ✅ Election (inactive)

### 3. Start the Backend

```bash
npm start        # Production
npm run dev      # Development (nodemon)
```

Server runs on: `http://localhost:5000`

### 4. Frontend Setup

Open `frontend/index.html` with a local server:

```bash
# Using VS Code Live Server (recommended)
# Right-click index.html → Open with Live Server

# Or using Python
cd frontend
python -m http.server 5500

# Or using npx
npx serve frontend -p 5500
```

Open: `http://localhost:5500`

---

## 🔐 Default Credentials

| Role    | Email                | Password   |
|---------|----------------------|------------|
| Admin   | admin@college.edu    | Admin@123  |

| Student Roll | Email               |
|--------------|---------------------|
| CS2021001    | aryan@college.edu   |
| CS2021002    | priya@college.edu   |
| CS2021003    | rohit@college.edu   |

> **Dev Mode**: If email is not configured, OTPs print to the backend console.

---

## 📡 API Reference

### Auth Routes (`/api/auth`)
| Method | Endpoint          | Description          |
|--------|-------------------|----------------------|
| POST   | `/send-otp`       | Send OTP to student  |
| POST   | `/verify-otp`     | Verify OTP → JWT     |

### Vote Routes (`/api/vote`)
| Method | Endpoint          | Auth    | Description        |
|--------|-------------------|---------|--------------------|
| GET    | `/candidates`     | Voting JWT | Get candidates  |
| POST   | `/cast`           | Voting JWT | Cast vote       |

### Admin Routes (`/api/admin`)
| Method | Endpoint              | Auth    | Description          |
|--------|-----------------------|---------|----------------------|
| POST   | `/login`              | —       | Admin login → JWT    |
| GET    | `/dashboard`          | Admin   | Dashboard stats      |
| POST   | `/election/control`   | Admin   | start/stop/reset     |
| GET    | `/election`           | Admin   | Election status      |

### Student Routes (`/api/students`)
| Method | Endpoint          | Auth    | Description         |
|--------|-------------------|---------|---------------------|
| GET    | `/`               | Admin   | List students       |
| POST   | `/`               | Admin   | Add student         |
| PUT    | `/:id`            | Admin   | Update student      |
| DELETE | `/:id`            | Admin   | Delete student      |
| POST   | `/upload-csv`     | Admin   | Bulk CSV upload     |
| GET    | `/export-csv`     | Admin   | Export students CSV |

### Candidate Routes (`/api/candidates`)
| Method | Endpoint    | Auth    | Description         |
|--------|-------------|---------|---------------------|
| GET    | `/`         | Public  | List candidates     |
| POST   | `/`         | Admin   | Add candidate       |
| PUT    | `/:id`      | Admin   | Update candidate    |
| DELETE | `/:id`      | Admin   | Remove candidate    |

### Results Routes (`/api/results`)
| Method | Endpoint    | Auth    | Description         |
|--------|-------------|---------|---------------------|
| GET    | `/`         | Public  | Live results        |
| GET    | `/export`   | Admin   | Export results CSV  |

---

## 🔄 Student Voting Flow

```
Roll Number Entry → OTP Email Sent (2 min expiry, 3 attempts)
       ↓
OTP Verified → Short-lived JWT (15 min)
       ↓
View Candidates → Select One → Confirm Modal
       ↓
Vote Cast → hasVoted = true → Show Success
```

---

## 🛡️ Security Features

- ✅ OTP: 6-digit, 2-minute expiry, max 3 attempts
- ✅ Rate limiting: 5 OTP requests/15 min per IP+roll
- ✅ JWT voting token: expires in 15 minutes
- ✅ Admin JWT: 7-day, bcrypt password hashing
- ✅ Duplicate vote prevention at DB level (unique index on Vote.studentId)
- ✅ Input validation on all routes
- ✅ CORS restricted to allowed origins

---

## 🎨 Frontend Pages

| Page               | Path                      |
|--------------------|---------------------------|
| Home               | `/index.html`             |
| Student Login      | `/pages/login.html`       |
| OTP Verify         | `/pages/otp.html`         |
| Vote               | `/pages/vote.html`        |
| Live Results       | `/pages/results.html`     |
| Admin Login        | `/pages/admin-login.html` |
| Admin Dashboard    | `/pages/dashboard.html`   |

---

## 📊 CSV Upload Format

```csv
name,roll,email
Aryan Sharma,CS2024001,aryan@college.edu
Priya Singh,CS2024002,priya@college.edu
```

Use the provided `sample_students.csv` to test.

---

## 🚀 Tech Stack

| Layer      | Technology                         |
|------------|------------------------------------|
| Frontend   | HTML5, CSS3, Vanilla JavaScript    |
| Charts     | Chart.js 4.4                       |
| Backend    | Node.js + Express.js               |
| Database   | MongoDB + Mongoose                 |
| Auth       | JWT + bcryptjs                     |
| OTP Email  | Nodemailer (Gmail SMTP)            |
| CSV Parse  | csv-parser + multer                |
| Security   | express-rate-limit                 |
