/* ═══════════════════════════════════════════════════
   COLLEGE VOTING SYSTEM — Shared Utilities
═══════════════════════════════════════════════════ */

const API_BASE = 'http://localhost:5000/api';

// ─── Toast Notifications ──────────────────────────────
const Toast = {
  container: null,
  init() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'toast-container';
      document.body.appendChild(this.container);
    }
  },
  show(message, type = 'info', duration = 3500) {
    this.init();
    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || 'ℹ️'}</span>
      <span class="toast-msg">${message}</span>
      <span class="toast-close" onclick="this.parentElement.remove()">✕</span>
    `;
    this.container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('hide');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },
  success(msg, dur) { this.show(msg, 'success', dur); },
  error(msg, dur)   { this.show(msg, 'error', dur || 4500); },
  info(msg, dur)    { this.show(msg, 'info', dur); },
  warning(msg, dur) { this.show(msg, 'warning', dur); }
};

// ─── API Helper ───────────────────────────────────────
const API = {
  async request(endpoint, options = {}) {
    const token = options.token || localStorage.getItem('adminToken') || localStorage.getItem('votingToken');
    const headers = { 'Content-Type': 'application/json', ...options.headers };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers,
        body: options.body ? JSON.stringify(options.body) : undefined
      });
      const data = await res.json();
      return { ok: res.ok, status: res.status, data };
    } catch (err) {
      return { ok: false, status: 0, data: { success: false, message: 'Network error. Is the server running?' } };
    }
  },
  get(url, opts)    { return this.request(url, { method: 'GET', ...opts }); },
  post(url, body, opts) { return this.request(url, { method: 'POST', body, ...opts }); },
  put(url, body, opts)  { return this.request(url, { method: 'PUT', body, ...opts }); },
  delete(url, opts)     { return this.request(url, { method: 'DELETE', ...opts }); },

  async uploadFile(endpoint, formData) {
    const token = localStorage.getItem('adminToken');
    const headers = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    try {
      const res = await fetch(`${API_BASE}${endpoint}`, { method: 'POST', headers, body: formData });
      const data = await res.json();
      return { ok: res.ok, data };
    } catch {
      return { ok: false, data: { success: false, message: 'Upload failed.' } };
    }
  }
};

// ─── Loading State ────────────────────────────────────
const Loader = {
  setBtn(btn, loading, text) {
    if (!btn) return;
    if (loading) {
      btn._origText = btn.innerHTML;
      btn.innerHTML = `<span class="spinner"></span> ${text || 'Loading...'}`;
      btn.disabled = true;
    } else {
      btn.innerHTML = btn._origText || text || 'Submit';
      btn.disabled = false;
    }
  },
  show() {
    let overlay = document.getElementById('global-loader');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'global-loader';
      overlay.className = 'loading-overlay';
      overlay.innerHTML = '<div class="spinner"></div>';
      document.body.appendChild(overlay);
    }
    overlay.style.display = 'grid';
  },
  hide() {
    const overlay = document.getElementById('global-loader');
    if (overlay) overlay.style.display = 'none';
  }
};

// ─── Auth Guards ──────────────────────────────────────
const Auth = {
  requireAdmin() {
    if (!localStorage.getItem('adminToken')) {
      window.location.href = 'admin-login.html';
      return false;
    }
    return true;
  },
  requireVoting() {
    if (!localStorage.getItem('votingToken')) {
      window.location.href = 'login.html';
      return false;
    }
    return true;
  },
  logoutAdmin() {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminData');
    window.location.href = 'admin-login.html';
  },
  logoutStudent() {
    localStorage.removeItem('votingToken');
    localStorage.removeItem('studentData');
    localStorage.removeItem('studentId');
    window.location.href = 'index.html';
  }
};

// ─── Countdown Timer ──────────────────────────────────
function startCountdown(seconds, displayEl, onExpire) {
  let remaining = seconds;
  const update = () => {
    if (!displayEl) return;
    const m = Math.floor(remaining / 60).toString().padStart(2, '0');
    const s = (remaining % 60).toString().padStart(2, '0');
    displayEl.textContent = `${m}:${s}`;
    if (remaining <= 10) displayEl.style.color = 'var(--accent-red)';
    if (remaining <= 0) { clearInterval(timer); if (onExpire) onExpire(); }
    remaining--;
  };
  update();
  const timer = setInterval(update, 1000);
  return timer;
}

// ─── Format Helpers ───────────────────────────────────
function formatDate(d) {
  if (!d) return 'N/A';
  return new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
}

function formatNumber(n) {
  return Number(n).toLocaleString('en-IN');
}

// ─── Election Timer (live countdown) ──────────────────
async function renderElectionTimer(el) {
  if (!el) return;
  const { data } = await API.get('/admin/election');
  const election = data?.election;
  if (!election || election.status !== 'active') return;
  if (!election.scheduledEnd) return;

  const end = new Date(election.scheduledEnd);
  const tick = () => {
    const diff = Math.max(0, Math.floor((end - new Date()) / 1000));
    if (diff <= 0) { el.textContent = 'Election Ended'; return; }
    const h = Math.floor(diff / 3600);
    const m = Math.floor((diff % 3600) / 60);
    const s = diff % 60;
    el.textContent = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
  };
  tick();
  setInterval(tick, 1000);
}
