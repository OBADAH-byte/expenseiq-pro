const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const Admin = require('../models/Admin');
const Student = require('../models/Student');
const Vote = require('../models/Vote');
const Candidate = require('../models/Candidate');
const Election = require('../models/Election');
const { protect } = require('../middleware/auth');

// Login rate limiter
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { success: false, message: 'Too many login attempts. Try again in 15 minutes.' }
});

// POST /api/admin/login
router.post('/login', loginLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const admin = await Admin.findOne({ email: email.toLowerCase() }).select('+password');
    if (!admin) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    const isMatch = await admin.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    await Admin.findByIdAndUpdate(admin._id, { lastLogin: new Date() });

    const token = jwt.sign({ id: admin._id, role: admin.role }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRE || '7d'
    });

    res.json({
      success: true,
      token,
      admin: { name: admin.name, email: admin.email, role: admin.role }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Login failed.' });
  }
});

// GET /api/admin/dashboard
router.get('/dashboard', protect, async (req, res) => {
  try {
    const [totalStudents, totalVotes, candidates, election] = await Promise.all([
      Student.countDocuments({ isActive: true }),
      Vote.countDocuments(),
      Candidate.find({ isActive: true }).select('name votes image').lean(),
      Election.findOne()
    ]);

    const votingPercentage = totalStudents > 0
      ? ((totalVotes / totalStudents) * 100).toFixed(1)
      : 0;

    res.json({
      success: true,
      data: {
        totalStudents,
        totalVotes,
        votingPercentage,
        candidates,
        election: election || { status: 'inactive', title: 'No Election Configured' }
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch dashboard data.' });
  }
});

// POST /api/admin/election/control
router.post('/election/control', protect, async (req, res) => {
  try {
    const { action, title, scheduledEnd } = req.body;

    let election = await Election.findOne();
    if (!election) election = new Election();

    if (action === 'start') {
      election.status = 'active';
      election.startTime = new Date();
      election.endTime = null;
      if (title) election.title = title;
      if (scheduledEnd) election.scheduledEnd = new Date(scheduledEnd);
    } else if (action === 'stop') {
      election.status = 'closed';
      election.endTime = new Date();
    } else if (action === 'reset') {
      election.status = 'inactive';
      election.startTime = null;
      election.endTime = null;
    } else {
      return res.status(400).json({ success: false, message: 'Invalid action. Use: start, stop, reset' });
    }

    await election.save();
    res.json({ success: true, message: `Election ${action}ed successfully.`, election });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Election control failed.' });
  }
});

// GET /api/admin/election
router.get('/election', protect, async (req, res) => {
  try {
    const election = await Election.findOne();
    res.json({ success: true, election: election || { status: 'inactive' } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch election status.' });
  }
});

// GET /api/admin/me
router.get('/me', protect, async (req, res) => {
  res.json({ success: true, admin: { name: req.admin.name, email: req.admin.email, role: req.admin.role } });
});

module.exports = router;
