const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const Student = require('../models/Student');
const Election = require('../models/Election');
const { sendOTP } = require('../middleware/email');

// OTP rate limiter: 5 requests per 15 minutes per IP
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { success: false, message: 'Too many OTP requests. Please wait 15 minutes.' },
  keyGenerator: (req) => req.ip + ':' + (req.body.roll || '')
});

// Generate 6-digit OTP
const generateOTP = () => {
  return crypto.randomInt(100000, 999999).toString();
};

// POST /api/auth/send-otp
router.post('/send-otp', otpLimiter, async (req, res) => {
  try {
    const { roll } = req.body;

    if (!roll || roll.trim() === '') {
      return res.status(400).json({ success: false, message: 'Roll number is required.' });
    }

    // Check election status
    const election = await Election.findOne();
    if (!election || election.status !== 'active') {
      return res.status(403).json({ success: false, message: 'Election is not currently active.' });
    }

    // Find student
    const student = await Student.findOne({ roll: roll.trim().toUpperCase(), isActive: true });
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student not found. Please contact admin.' });
    }

    // Check if already voted
    if (student.hasVoted) {
      return res.status(403).json({ success: false, message: 'You have already cast your vote.' });
    }

    // Check OTP request rate (max 3 OTP requests per hour per student)
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    if (student.lastOtpRequest && student.lastOtpRequest > oneHourAgo && student.otpRequestCount >= 5) {
      return res.status(429).json({ success: false, message: 'Too many OTP requests. Try again in an hour.' });
    }

    // Generate OTP
    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + (parseInt(process.env.OTP_EXPIRY_MINUTES) || 2) * 60 * 1000);

    // Update student
    await Student.findByIdAndUpdate(student._id, {
      otp,
      otpExpiry,
      otpAttempts: 0,
      otpRequestCount: student.lastOtpRequest > oneHourAgo ? student.otpRequestCount + 1 : 1,
      lastOtpRequest: new Date()
    });

    // Send OTP
    await sendOTP(student.email, student.name, otp);

    // Mask email for response
    const maskedEmail = student.email.replace(/(.{2})(.*)(@.*)/, '$1***$3');

    res.json({
      success: true,
      message: `OTP sent to ${maskedEmail}`,
      studentId: student._id,
      expiresIn: 120 // seconds
    });

  } catch (err) {
    console.error('Send OTP Error:', err);
    res.status(500).json({ success: false, message: 'Failed to send OTP. Try again.' });
  }
});

// POST /api/auth/verify-otp
router.post('/verify-otp', async (req, res) => {
  try {
    const { studentId, otp } = req.body;

    if (!studentId || !otp) {
      return res.status(400).json({ success: false, message: 'Student ID and OTP are required.' });
    }

    const student = await Student.findById(studentId);
    if (!student) {
      return res.status(404).json({ success: false, message: 'Student not found.' });
    }

    if (student.hasVoted) {
      return res.status(403).json({ success: false, message: 'You have already voted.' });
    }

    // Check max attempts
    const maxAttempts = parseInt(process.env.MAX_OTP_ATTEMPTS) || 3;
    if (student.otpAttempts >= maxAttempts) {
      return res.status(429).json({ success: false, message: 'Maximum OTP attempts exceeded. Request a new OTP.' });
    }

    // Check OTP expiry
    if (!student.otpExpiry || new Date() > student.otpExpiry) {
      return res.status(400).json({ success: false, message: 'OTP has expired. Please request a new one.' });
    }

    // Verify OTP
    if (student.otp !== otp.trim()) {
      await Student.findByIdAndUpdate(student._id, { $inc: { otpAttempts: 1 } });
      const remaining = maxAttempts - (student.otpAttempts + 1);
      return res.status(400).json({
        success: false,
        message: `Invalid OTP. ${remaining > 0 ? `${remaining} attempts remaining.` : 'No attempts left.'}`
      });
    }

    // OTP verified - clear OTP
    await Student.findByIdAndUpdate(student._id, {
      otp: null,
      otpExpiry: null,
      otpAttempts: 0
    });

    // Create a short-lived voting token
    const jwt = require('jsonwebtoken');
    const votingToken = jwt.sign(
      { studentId: student._id, roll: student.roll, type: 'voting' },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );

    res.json({
      success: true,
      message: 'OTP verified successfully.',
      token: votingToken,
      student: {
        name: student.name,
        roll: student.roll
      }
    });

  } catch (err) {
    console.error('Verify OTP Error:', err);
    res.status(500).json({ success: false, message: 'Verification failed. Try again.' });
  }
});

module.exports = router;
