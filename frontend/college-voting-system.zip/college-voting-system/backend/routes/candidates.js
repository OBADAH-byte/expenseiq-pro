const express = require('express');
const router = express.Router();
const Candidate = require('../models/Candidate');
const { protect } = require('../middleware/auth');

// GET /api/candidates - Public: get all active candidates
router.get('/', async (req, res) => {
  try {
    const candidates = await Candidate.find({ isActive: true }).select('name position image description votes').lean();
    res.json({ success: true, candidates });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch candidates.' });
  }
});

// POST /api/candidates - Admin: add candidate
router.post('/', protect, async (req, res) => {
  try {
    const { name, position, image, description } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, message: 'Candidate name is required.' });
    }

    const candidateImage = image || `https://ui-avatars.com/api/?background=6366f1&color=fff&size=200&name=${encodeURIComponent(name)}&bold=true&format=svg`;

    const candidate = await Candidate.create({ name, position, image: candidateImage, description });
    res.status(201).json({ success: true, message: 'Candidate added.', candidate });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/candidates/:id - Admin: update candidate
router.put('/:id', protect, async (req, res) => {
  try {
    const { name, position, image, description } = req.body;
    const candidate = await Candidate.findByIdAndUpdate(
      req.params.id,
      { name, position, image, description },
      { new: true, runValidators: true }
    );
    if (!candidate) return res.status(404).json({ success: false, message: 'Candidate not found.' });
    res.json({ success: true, message: 'Candidate updated.', candidate });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/candidates/:id - Admin: delete candidate
router.delete('/:id', protect, async (req, res) => {
  try {
    const candidate = await Candidate.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
    if (!candidate) return res.status(404).json({ success: false, message: 'Candidate not found.' });
    res.json({ success: true, message: 'Candidate removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete candidate.' });
  }
});

// POST /api/candidates/reset-votes - Admin only
router.post('/reset-votes', protect, async (req, res) => {
  try {
    await Candidate.updateMany({}, { votes: 0 });
    res.json({ success: true, message: 'All votes reset.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to reset votes.' });
  }
});

module.exports = router;
