const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Student = require('../models/Student');
const Vote = require('../models/Vote');
const Candidate = require('../models/Candidate');
const Election = require('../models/Election');

// Middleware: verify voting token
const verifyVotingToken = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ success: false, message: 'Access denied.' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (decoded.type !== 'voting') return res.status(401).json({ success: false, message: 'Invalid token type.' });

    req.student = decoded;
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid or expired session. Please login again.' });
  }
};

// POST /api/vote/cast
router.post('/cast', verifyVotingToken, async (req, res) => {
  try {
    const { candidateId } = req.body;
    const studentId = req.student.studentId;

    if (!candidateId) {
      return res.status(400).json({ success: false, message: 'Please select a candidate.' });
    }

    // Check election status
    const election = await Election.findOne();
    if (!election || election.status !== 'active') {
      return res.status(403).json({ success: false, message: 'Election is not currently active.' });
    }

    // Verify student hasn't voted (double-check)
    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ success: false, message: 'Student not found.' });
    if (student.hasVoted) return res.status(403).json({ success: false, message: 'You have already voted.' });

    // Verify candidate exists
    const candidate = await Candidate.findById(candidateId);
    if (!candidate || !candidate.isActive) {
      return res.status(404).json({ success: false, message: 'Candidate not found.' });
    }

    // Check for existing vote (extra safety)
    const existingVote = await Vote.findOne({ studentId });
    if (existingVote) {
      await Student.findByIdAndUpdate(studentId, { hasVoted: true });
      return res.status(403).json({ success: false, message: 'You have already voted.' });
    }

    // Cast vote (atomic operation)
    await Promise.all([
      Vote.create({ studentId, candidateId }),
      Student.findByIdAndUpdate(studentId, { hasVoted: true, votedAt: new Date() }),
      Candidate.findByIdAndUpdate(candidateId, { $inc: { votes: 1 } })
    ]);

    res.json({
      success: true,
      message: `Vote cast successfully for ${candidate.name}!`,
      candidate: { name: candidate.name, image: candidate.image }
    });

  } catch (err) {
    console.error('Vote Cast Error:', err);
    if (err.code === 11000) {
      return res.status(403).json({ success: false, message: 'You have already voted.' });
    }
    res.status(500).json({ success: false, message: 'Failed to cast vote. Try again.' });
  }
});

// GET /api/vote/candidates - Get candidates for voting
router.get('/candidates', verifyVotingToken, async (req, res) => {
  try {
    const election = await Election.findOne();
    if (!election || election.status !== 'active') {
      return res.status(403).json({ success: false, message: 'Election is not active.' });
    }

    const student = await Student.findById(req.student.studentId).select('hasVoted name roll');
    if (student?.hasVoted) {
      return res.status(403).json({ success: false, message: 'You have already voted.' });
    }

    const candidates = await Candidate.find({ isActive: true }).select('name position image description').lean();

    res.json({
      success: true,
      candidates,
      election: { title: election.title, status: election.status }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch candidates.' });
  }
});

module.exports = router;
