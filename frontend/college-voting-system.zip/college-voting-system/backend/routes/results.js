const express = require('express');
const router = express.Router();
const Candidate = require('../models/Candidate');
const Student = require('../models/Student');
const Vote = require('../models/Vote');
const Election = require('../models/Election');
const { protect } = require('../middleware/auth');

// GET /api/results - Live results (public)
router.get('/', async (req, res) => {
  try {
    const [candidates, totalVotes, totalStudents, election] = await Promise.all([
      Candidate.find({ isActive: true }).select('name position image votes').sort({ votes: -1 }).lean(),
      Vote.countDocuments(),
      Student.countDocuments({ isActive: true }),
      Election.findOne()
    ]);

    const results = candidates.map(c => ({
      ...c,
      percentage: totalVotes > 0 ? ((c.votes / totalVotes) * 100).toFixed(1) : '0.0'
    }));

    const winner = results[0] || null;

    res.json({
      success: true,
      results,
      totalVotes,
      totalStudents,
      votingPercentage: totalStudents > 0 ? ((totalVotes / totalStudents) * 100).toFixed(1) : '0.0',
      election: election || { status: 'inactive' },
      winner: winner?.votes > 0 ? winner : null,
      timestamp: new Date()
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch results.' });
  }
});

// GET /api/results/export - Export results as CSV (admin)
router.get('/export', protect, async (req, res) => {
  try {
    const candidates = await Candidate.find({ isActive: true }).sort({ votes: -1 }).lean();
    const totalVotes = await Vote.countDocuments();

    let csvContent = 'Rank,Candidate Name,Position,Votes,Percentage\n';
    candidates.forEach((c, i) => {
      const pct = totalVotes > 0 ? ((c.votes / totalVotes) * 100).toFixed(1) : '0.0';
      csvContent += `${i + 1},"${c.name}","${c.position || 'N/A'}",${c.votes},${pct}%\n`;
    });
    csvContent += `\nTotal Votes,${totalVotes}\n`;

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="election_results.csv"');
    res.send(csvContent);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Export failed.' });
  }
});

module.exports = router;
