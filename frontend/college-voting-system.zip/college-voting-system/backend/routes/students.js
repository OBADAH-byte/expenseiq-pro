const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const path = require('path');
const Student = require('../models/Student');
const { protect } = require('../middleware/auth');

// Multer setup for CSV
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename: (req, file, cb) => cb(null, `csv_${Date.now()}_${file.originalname}`)
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'), false);
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

// GET /api/students - List all students (admin)
router.get('/', protect, async (req, res) => {
  try {
    const { search, page = 1, limit = 50, voted } = req.query;
    const query = { isActive: true };

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { roll: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    if (voted === 'true') query.hasVoted = true;
    if (voted === 'false') query.hasVoted = false;

    const total = await Student.countDocuments(query);
    const students = await Student.find(query)
      .select('-otp -otpExpiry -otpAttempts')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .lean();

    res.json({ success: true, students, total, page: parseInt(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch students.' });
  }
});

// POST /api/students - Add student
router.post('/', protect, async (req, res) => {
  try {
    const { name, roll, email } = req.body;

    if (!name || !roll || !email) {
      return res.status(400).json({ success: false, message: 'Name, roll, and email are required.' });
    }

    const student = await Student.create({ name: name.trim(), roll: roll.trim().toUpperCase(), email: email.trim().toLowerCase() });
    res.status(201).json({ success: true, message: 'Student added.', student });
  } catch (err) {
    if (err.code === 11000) {
      const field = Object.keys(err.keyPattern)[0];
      return res.status(400).json({ success: false, message: `${field} already exists.` });
    }
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/students/:id - Update student
router.put('/:id', protect, async (req, res) => {
  try {
    const { name, email } = req.body;
    const update = {};
    if (name) update.name = name.trim();
    if (email) update.email = email.trim().toLowerCase();

    const student = await Student.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found.' });

    res.json({ success: true, message: 'Student updated.', student });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/students/:id
router.delete('/:id', protect, async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(req.params.id, { isActive: false }, { new: true });
    if (!student) return res.status(404).json({ success: false, message: 'Student not found.' });
    res.json({ success: true, message: 'Student deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete student.' });
  }
});

// POST /api/students/upload-csv
router.post('/upload-csv', protect, upload.single('csv'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'Please upload a CSV file.' });
  }

  const results = [];
  const errors = [];
  let rowIndex = 0;

  try {
    await new Promise((resolve, reject) => {
      fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (row) => {
          rowIndex++;
          const name = row.name?.trim() || row.Name?.trim();
          const roll = row.roll?.trim().toUpperCase() || row.Roll?.trim().toUpperCase();
          const email = row.email?.trim().toLowerCase() || row.Email?.trim().toLowerCase();

          if (!name || !roll || !email) {
            errors.push({ row: rowIndex, error: `Missing fields: ${!name ? 'name' : ''} ${!roll ? 'roll' : ''} ${!email ? 'email' : ''}`.trim() });
          } else {
            results.push({ name, roll, email });
          }
        })
        .on('end', resolve)
        .on('error', reject);
    });

    // Bulk insert with duplicate handling
    let inserted = 0, duplicates = 0;

    for (const student of results) {
      try {
        await Student.create(student);
        inserted++;
      } catch (e) {
        if (e.code === 11000) {
          duplicates++;
          errors.push({ row: student.roll, error: 'Duplicate roll/email' });
        } else {
          errors.push({ row: student.roll, error: e.message });
        }
      }
    }

    // Cleanup temp file
    fs.unlinkSync(req.file.path);

    res.json({
      success: true,
      message: `CSV processed. ${inserted} students added.`,
      summary: { total: results.length, inserted, duplicates, errors: errors.length },
      errors: errors.slice(0, 20) // Return first 20 errors
    });

  } catch (err) {
    if (fs.existsSync(req.file?.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ success: false, message: 'CSV processing failed: ' + err.message });
  }
});

// GET /api/students/export-csv - Export students as CSV
router.get('/export-csv', protect, async (req, res) => {
  try {
    const students = await Student.find({ isActive: true }).select('name roll email hasVoted votedAt').lean();

    let csv = 'Name,Roll,Email,Has Voted,Voted At\n';
    students.forEach(s => {
      csv += `"${s.name}","${s.roll}","${s.email}","${s.hasVoted ? 'Yes' : 'No'}","${s.votedAt ? new Date(s.votedAt).toLocaleString() : 'N/A'}"\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="students_export.csv"');
    res.send(csv);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Export failed.' });
  }
});

module.exports = router;
