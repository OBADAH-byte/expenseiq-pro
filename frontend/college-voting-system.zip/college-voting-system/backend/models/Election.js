const mongoose = require('mongoose');

const electionSchema = new mongoose.Schema({
  title: {
    type: String,
    default: 'Student Council Election 2024'
  },
  status: {
    type: String,
    enum: ['inactive', 'active', 'closed'],
    default: 'inactive'
  },
  startTime: {
    type: Date,
    default: null
  },
  endTime: {
    type: Date,
    default: null
  },
  scheduledEnd: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Election', electionSchema);
