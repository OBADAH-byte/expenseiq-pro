const mongoose = require('mongoose');

const candidateSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Candidate name is required'],
    trim: true,
    maxlength: [100, 'Name cannot exceed 100 characters']
  },
  position: {
    type: String,
    trim: true,
    default: 'Student Representative'
  },
  image: {
    type: String,
    default: 'https://ui-avatars.com/api/?background=6366f1&color=fff&size=200&name='
  },
  description: {
    type: String,
    trim: true,
    default: ''
  },
  votes: {
    type: Number,
    default: 0
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Candidate', candidateSchema);
