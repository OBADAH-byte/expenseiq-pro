const nodemailer = require('nodemailer');

const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    },
    tls: {
      rejectUnauthorized: false
    }
  });
};

const sendOTPEmail = async (email, name, otp) => {
  const transporter = createTransporter();

  const mailOptions = {
    from: process.env.EMAIL_FROM || `College Voting System <${process.env.EMAIL_USER}>`,
    to: email,
    subject: '🗳️ Your Voting OTP - College Election',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: 'Segoe UI', Arial, sans-serif; background: #0f0f1a; color: #e2e8f0; margin: 0; padding: 20px; }
          .container { max-width: 520px; margin: 0 auto; background: #1a1a2e; border-radius: 16px; overflow: hidden; border: 1px solid #2d2d4e; }
          .header { background: linear-gradient(135deg, #6366f1, #8b5cf6); padding: 32px 40px; text-align: center; }
          .header h1 { margin: 0; color: white; font-size: 24px; font-weight: 700; letter-spacing: -0.5px; }
          .header p { margin: 8px 0 0; color: rgba(255,255,255,0.8); font-size: 14px; }
          .body { padding: 40px; }
          .greeting { font-size: 16px; color: #94a3b8; margin-bottom: 24px; }
          .otp-box { background: #0f0f1a; border: 2px solid #6366f1; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0; }
          .otp-label { font-size: 12px; text-transform: uppercase; letter-spacing: 2px; color: #6366f1; margin-bottom: 12px; }
          .otp-code { font-size: 48px; font-weight: 800; letter-spacing: 12px; color: #a5b4fc; font-family: 'Courier New', monospace; }
          .warning { background: rgba(251,191,36,0.1); border: 1px solid rgba(251,191,36,0.3); border-radius: 8px; padding: 16px; margin-top: 24px; }
          .warning p { margin: 0; font-size: 13px; color: #fbbf24; }
          .footer { background: #0f0f1a; padding: 20px 40px; text-align: center; border-top: 1px solid #2d2d4e; }
          .footer p { margin: 0; font-size: 12px; color: #475569; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🗳️ College Voting System</h1>
            <p>Secure Election Portal</p>
          </div>
          <div class="body">
            <p class="greeting">Hello <strong>${name}</strong>,</p>
            <p style="color: #94a3b8; font-size: 15px;">Your One-Time Password for voting verification is:</p>
            <div class="otp-box">
              <div class="otp-label">Your OTP Code</div>
              <div class="otp-code">${otp}</div>
            </div>
            <div class="warning">
              <p>⚠️ This OTP is valid for <strong>2 minutes</strong> only. Do not share this code with anyone. You have a maximum of 3 attempts.</p>
            </div>
          </div>
          <div class="footer">
            <p>© 2024 College Voting System | This is an automated message</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  await transporter.sendMail(mailOptions);
};

// For development/testing - log OTP to console if email not configured
const sendOTP = async (email, name, otp) => {
  if (!process.env.EMAIL_USER || process.env.EMAIL_USER === 'your_email@gmail.com') {
    console.log(`\n📧 OTP for ${name} (${email}): ${otp}\n`);
    return { messageId: 'dev-mode', preview: `OTP logged to console: ${otp}` };
  }
  return await sendOTPEmail(email, name, otp);
};

module.exports = { sendOTP };
