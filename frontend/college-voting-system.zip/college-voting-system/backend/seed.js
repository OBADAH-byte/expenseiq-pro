require('dotenv').config();
const mongoose = require('mongoose');
const Admin = require('./models/Admin');
const Student = require('./models/Student');
const Candidate = require('./models/Candidate');
const Election = require('./models/Election');

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/college_voting');
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await Promise.all([
      Admin.deleteMany({}),
      Student.deleteMany({}),
      Candidate.deleteMany({}),
      Election.deleteMany({})
    ]);
    console.log('🗑️  Cleared existing data');

    // Create admin
    await Admin.create({
      name: 'Super Admin',
      email: 'admin@college.edu',
      password: 'Admin@123',
      role: 'superadmin'
    });
    console.log('👤 Admin created: admin@college.edu / Admin@123');

    // Create students
    const students = [
      { name: 'Aryan Sharma',    roll: 'CS2021001', email: 'aryan@college.edu' },
      { name: 'Priya Singh',     roll: 'CS2021002', email: 'priya@college.edu' },
      { name: 'Rohit Kumar',     roll: 'CS2021003', email: 'rohit@college.edu' },
      { name: 'Neha Gupta',      roll: 'CS2021004', email: 'neha@college.edu' },
      { name: 'Akash Verma',     roll: 'CS2021005', email: 'akash@college.edu' },
      { name: 'Divya Nair',      roll: 'EC2021001', email: 'divya@college.edu' },
      { name: 'Suresh Patel',    roll: 'EC2021002', email: 'suresh@college.edu' },
      { name: 'Meera Joshi',     roll: 'ME2021001', email: 'meera@college.edu' },
      { name: 'Karan Mehta',     roll: 'ME2021002', email: 'karan@college.edu' },
      { name: 'Ankita Das',      roll: 'IT2021001', email: 'ankita@college.edu' },
    ];
    await Student.insertMany(students);
    console.log(`📚 ${students.length} students created`);

    // Create candidates
    const candidates = [
      {
        name: 'Rahul Verma',
        position: 'President',
        image: 'https://ui-avatars.com/api/?background=6366f1&color=fff&size=200&name=Rahul+Verma&bold=true',
        description: 'Passionate about student welfare and innovation in education.'
      },
      {
        name: 'Sneha Patel',
        position: 'President',
        image: 'https://ui-avatars.com/api/?background=ec4899&color=fff&size=200&name=Sneha+Patel&bold=true',
        description: 'Dedicated to improving campus life and student resources.'
      },
      {
        name: 'Aditya Rao',
        position: 'President',
        image: 'https://ui-avatars.com/api/?background=10b981&color=fff&size=200&name=Aditya+Rao&bold=true',
        description: 'Focused on technical and cultural development of students.'
      },
      {
        name: 'Pooja Mishra',
        position: 'President',
        image: 'https://ui-avatars.com/api/?background=f59e0b&color=fff&size=200&name=Pooja+Mishra&bold=true',
        description: 'Committed to transparency and student empowerment.'
      }
    ];
    await Candidate.insertMany(candidates);
    console.log(`🎯 ${candidates.length} candidates created`);

    // Create election (inactive)
    await Election.create({
      title: 'Student Council Election 2024',
      status: 'inactive'
    });
    console.log('🗳️  Election created (inactive)');

    console.log('\n✅ Database seeded successfully!');
    console.log('─────────────────────────────────────────');
    console.log('Admin Login:  admin@college.edu / Admin@123');
    console.log('Sample Roll:  CS2021001 → aryan@college.edu');
    console.log('─────────────────────────────────────────');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    process.exit(1);
  }
};

seed();
